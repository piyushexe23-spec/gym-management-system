"""
URL configuration for gym project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('admin/', admin.site.urls),
    path('logout/', views.logout_view, name='logout'),
    path('', views.index),
    path('client/', views.client),
    path('client_detail/<int:client_id>/', views.client_detail, name='client_detail'),
    path('membership/', views.membership),
    path('test/', views.test),
    path('add-client/', views.add_client, name='add_client'),
    path('add-Membership/', views.add_membership, name='add_Membership'),
    path('add-attendance/', views.add_attendance, name='add_attendance'),
    path('add-invoice/', views.add_invoice, name='add_invoice'),
    path('add-designation/', views.add_designation, name='add_designation'),
    path("add_shift/", views.add_shift, name="add_shift"),
    path('add_department/', views.add_department, name='add_department'),
    path("add-trainer/", views.add_trainer, name="add_trainer"),
    path('designation/', views.designation),
    path('Staff_attendence/', views.Staff_attendence),
    path('trainer/', views.trainer),
    path('shift/', views.shift),
    path('holiday/', views.holiday),
    path('dipartment/', views.dipartment),
    path('login/', views.login_),
    path("login_view/", views.login_view, name="login_view"),
    path('trainer_detail/<str:trainer_id>/', views.trainer_detail, name= 'trainer_detail'),
    path("add_holiday/", views.add_holiday, name="add_holiday"),

    path('edit-client/<int:client_id>/', views.edit_client, name='edit_client'),
    path('get-client/<int:client_id>/', views.get_client, name='get_client'),
    path('delete-client/<int:client_id>/', views.delete_client, name='delete_client'),

    path('edit-membership/<int:membership_id>/', views.edit_membership, name='edit_membership'),
    path('get-membership/<int:membership_id>/', views.get_membership, name='get_membership'),
    path('delete-membership/<int:membership_id>/', views.delete_membership, name='delete_membership'),

    path("edit-designation/<int:designation_id>/", views.edit_designation, name="edit_designation"),
    path("get-designation/<int:designation_id>/", views.get_designation, name="get_designation"),
    path('delete-designation/<int:designation_id>/', views.delete_designation, name='delete_designation'),

    path("get-shift/<int:shift_id>/", views.get_shift, name="get_shift"),
    path("edit-shift/<int:shift_id>/", views.edit_shift, name="edit_shift"),
    path('delete-shift/<int:shift_id>/', views.delete_shift, name='delete_shift'),
    
    path('get-department/<int:pk>/', views.get_department, name='get_department'),
    path('edit-department/<int:pk>/', views.edit_department, name='edit_department'),

    path("get-holiday/<int:holiday_id>/", views.get_holiday, name="get_holiday"),
    path("edit-holiday/<int:holiday_id>/", views.edit_holiday, name="edit_holiday"),
    path('delete-holiday/<int:holiday_id>/', views.delete_holiday, name='delete_holiday'),

    path('edit-trainer/<int:trainer_id>/', views.edit_trainer, name='edit_trainer'),
    path('get-trainer/<int:trainer_id>/', views.get_trainer, name='get_trainer'),
    path('delete-trainer/<int:trainer_id>/', views.delete_trainer, name='delete_trainer'),
   
    path("add_staff_attendance/", views.add_staff_attendance, name="add_staff_attendance"),
    path("get-attendance/<int:attendance_id>/", views.get_attendance, name="get_attendance"),
    path("edit-attendance/<int:attendance_id>/", views.edit_attendance, name="edit_attendance"),
    path('delete-attendance/<int:attendance_id>/', views.delete_attendance, name='delete_attendance'),
    
    path("invoice/<int:invoice_id>/pdf/", views.generate_invoice_pdf, name="generate_invoice_pdf"),

    
    path('edit-invoice/<int:invoice_id>/', views.edit_invoice, name='edit_invoice'),
    path('get-invoice/<int:invoice_id>/', views.get_invoice, name='get_invoice'),
    path('delete-invoice/<int:invoice_id>/', views.delete_invoice, name='delete_invoice'),

    path("add-training/", views.add_training, name="add_training"),
    path("get-training/<int:training_id>/", views.get_training, name="get_training"),
    path("edit-training/<int:training_id>/", views.edit_training, name="edit_training"),
    path("delete-training/<int:training_id>/", views.delete_training, name="delete_training"),
    path('renew-membership/', views.renew_membership, name='renew_membership'),

















]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)