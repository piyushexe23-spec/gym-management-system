from django.contrib.auth import authenticate, login,get_user_model
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, JsonResponse, Http404
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from manager.models import Client
from manager.models import Membership,Attendance,Invoice,Designation,Shift,Department,Trainer,Holiday,TrainerAttendance,PersonalTraining
from datetime import datetime
from calendar import monthrange
from django.contrib import messages
from django.utils.dateparse import parse_date, parse_time
from django.contrib.auth.models import User
from django.contrib.auth import logout
from datetime import date
from weasyprint import HTML
import tempfile
from django.utils import timezone
from datetime import timedelta
from dateutil.relativedelta import relativedelta
from django.db.models import Count



def login_(request):
    return render(request,"login.html")

def logout_view(request):
    logout(request)
    return redirect('/login/')

@csrf_exempt 
def login_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        errors = {}

        try:
            # Find user by email
            user_obj = User.objects.get(email=email)
        except User.DoesNotExist:
            errors["email"] = "User with this email does not exist."
            return JsonResponse({"success": False, "errors": errors})

        # Authenticate with username but using email mapping
        user = authenticate(request, username=user_obj.username, password=password)

        if user is not None:
            login(request, user)
            return JsonResponse({"success": True, "redirect_url": "/"})
        else:
            errors["password"] = "Invalid email or password."
            return JsonResponse({"success": False, "errors": errors})

    return JsonResponse({"success": False, "errors": {"general": "Invalid request method."}})


@login_required(login_url='/login/')
def index(request):
    return render(request,"index.html",{'name':'Dashboard'})

@login_required(login_url='/login/')
def holiday(request):
    holiday=Holiday.objects.all()
    return render(request,"holiday.html",{'name':'Holiday','holiday':holiday})

@login_required(login_url='/login/')
def Staff_attendence(request):
    trainers = Trainer.objects.select_related('shift').all()  
    return render(request, "Attendence.html", {'name': 'Staff Attendence', 'trainers': trainers})



    
@login_required(login_url='/login/')
def client(request):
    today = timezone.now().date()
    filter_type = request.GET.get('filter')  # 'expired' or 'soon'

    # Base queryset
    clients = Client.objects.all()
    memberships = Membership.objects.filter(status='active')
    trainers = Trainer.objects.filter(status="active")

    # Filters
    expired_clients_qs = Client.objects.filter(membership_end__lt=today)
    expiring_soon_qs = Client.objects.filter(
        membership_end__gte=today,
        membership_end__lte=today + timedelta(days=7)
    )

    # Apply filter if requested
    if filter_type == 'expired':
        clients = expired_clients_qs
    elif filter_type == 'soon':
        clients = expiring_soon_qs

    # Stats
    total_clients = Client.objects.count()
    expired_clients = expired_clients_qs.count()
    expiring_soon_clients = expiring_soon_qs.count()

    # Render
    return render(
        request,
        'clients.html',
        {
            'clients': clients,
            'memberships': memberships,
            'trainers': trainers,
            'total_clients': total_clients,
            'expired_clients': expired_clients,
            'expiring_soon_clients': expiring_soon_clients,
            'today': today,
            'filter_type': filter_type,
        }
    )

@login_required(login_url='/login/')
def client_detail(request, client_id):
    client = get_object_or_404(Client, id=client_id)

    attendances = Attendance.objects.filter(client=client).order_by('-date')
    invoice = Invoice.objects.filter(client=client)

    total_present = Attendance.objects.filter(client=client, status="present").count()
    total_invoice = invoice.count()
    unpaid_invoice = invoice.filter(status='unpaid').count()

    # 🔹 Fetch all active memberships for dropdown
    memberships = Membership.objects.filter(status="active")

    return render(request, "client-details.html", {
        'name': 'Client Detail',
        'client': client,
        'attendances': attendances,
        'invoice': invoice,
        'total_present': total_present,
        'total_invoice': total_invoice,
        'unpaid_invoice': unpaid_invoice,
        'memberships': memberships,  
    })


@login_required(login_url='/login/')
def trainer_detail(request, trainer_id):
    trainer = Trainer.objects.get(id=trainer_id)
    trainings = PersonalTraining.objects.filter(trainer=trainer)
    attendance_records = TrainerAttendance.objects.filter(trainer=trainer).order_by('-date')  # latest first
    return render(
        request,
        "trainer-details.html",
        {
            'name': 'Trainer detail',
            'trainer': trainer,
            'attendance_records': attendance_records,
            'trainings':trainings
        }
    )



@login_required(login_url='/login/')
def membership(request):
    memberships = Membership.objects.all()
    total_membership = memberships.count()
    basic_count = Membership.objects.filter(access_level='basic').count()
    premium_count = Membership.objects.filter(access_level='premium').count()
    vip_count = Membership.objects.filter(access_level='vip').count()
    return render(
        request,
        "membership.html", 
        {
            'name':'Memberships',
            "memberships": memberships ,
            "total_membership": total_membership,
            "basic_count":basic_count,
            "premium_count":premium_count,
            "vip_count":vip_count
        }
    )

@login_required(login_url='/login/')
def test(request):
    return render(request,"test.html")

@login_required(login_url='/login/')
def trainer(request):
    designations = Designation.objects.all()
    departments = Department.objects.all()
    shifts = Shift.objects.all()
    trainers = Trainer.objects.all()
    total_trainer = trainers.count()
    return render(request, "trainer.html", {'name':'Trainers',"trainers": trainers,"designations": designations,"departments": departments,"shifts": shifts,"total_trainer":total_trainer})

@login_required(login_url='/login/')
def dipartment(request):
    departments = Department.objects.annotate(total_trainers=Count('trainers'))
    return render(request, "dipartment.html", {
        'name': 'Departments',
        "departments": departments
    })

@login_required(login_url='/login/')
def shift(request):
    shifts = Shift.objects.all().order_by("start_time")  # fetch all shifts
    return render(request, "shift.html", {'name':'Shifts',"shifts": shifts})

@login_required(login_url='/login/')
def designation(request):
    designations = Designation.objects.annotate(total_trainers=Count('trainers'))
    return render(request, "designation.html", {
        'name': 'Designations',
        "designations": designations
    })




@csrf_exempt  
def add_client(request):
    if request.method == "POST":
        try:
            profile_photo = request.FILES.get("profile_photo")
            name = request.POST.get("name")
            age = request.POST.get("age")
            gender = request.POST.get("gender")
            membership_plan_id = request.POST.get("membership_plan")
            trainer_id = request.POST.get("trainer")  # new field
            phone = request.POST.get("phone")
            email = request.POST.get("email")
            join_date_str = request.POST.get("join_date")

            # Validate required fields (trainer is NOT required)
            if not all([name, age, gender, membership_plan_id, phone, email, join_date_str]):
                return JsonResponse({"status": "error", "message": "All required fields must be filled"}, status=400)

            # Convert membership ID to object
            membership_plan = get_object_or_404(Membership, id=membership_plan_id)

            # Convert join_date string to date object
            join_date = datetime.strptime(join_date_str, "%Y-%m-%d").date()

            # Get trainer if provided
            trainer = None
            if trainer_id:
                trainer = get_object_or_404(Trainer, id=trainer_id)

            # Create the client
            client = Client.objects.create(
                profile_photo=profile_photo,
                name=name,
                age=age,
                gender=gender,
                membership_plan=membership_plan,
                trainer=trainer,   # can be None
                phone=phone,
                email=email,
                join_date=join_date
            )

            return JsonResponse({
                "status": "success",
                "id": client.id,
                "message": "Client added successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)



def edit_client(request, client_id):
    if request.method == "POST":
        try:
            client = get_object_or_404(Client, id=client_id)

            profile_photo = request.FILES.get("profile_photo")
            name = request.POST.get("name")
            age = request.POST.get("age")
            gender = request.POST.get("gender")
            membership_plan_id = request.POST.get("membership_plan")
            trainer_id = request.POST.get("trainer")  # NEW FIELD
            phone = request.POST.get("phone")
            email = request.POST.get("email")
            join_date_str = request.POST.get("join_date")

            # Validate required fields (trainer is optional)
            if not all([name, age, gender, membership_plan_id, phone, email, join_date_str]):
                return JsonResponse({"status": "error", "message": "All required fields must be filled"}, status=400)

            # Convert membership ID to object
            membership_plan = get_object_or_404(Membership, id=membership_plan_id)

            # Convert join_date string to date object
            join_date = datetime.strptime(join_date_str, "%Y-%m-%d").date()

            # Handle trainer (optional)
            trainer = None
            if trainer_id:
                trainer = get_object_or_404(Trainer, id=trainer_id)

            # Update client
            client.name = name
            client.age = age
            client.gender = gender
            client.membership_plan = membership_plan
            client.trainer = trainer  # can be None
            client.phone = phone
            client.email = email
            client.join_date = join_date
            if profile_photo:
                client.profile_photo = profile_photo
            client.save()

            return JsonResponse({
                "status": "success",
                "id": client.id,
                "message": "Client updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_client(request, client_id):
    client = get_object_or_404(Client, id=client_id)
    return JsonResponse({
        "status": "success",
        "client": {
            "id": client.id,
            "name": client.name,
            "age": client.age,
            "gender": client.gender,
            "membership_plan": client.membership_plan.id,
            "trainer": client.trainer.id if client.trainer else "",  # NEW
            "phone": client.phone,
            "email": client.email,
            "join_date": client.join_date.strftime("%Y-%m-%d")
        }
    })


def delete_client(request, client_id):
    client = get_object_or_404(Client, id=client_id)
    client.delete()
    return redirect('/client/')

@csrf_exempt  # If you are sending CSRF token in AJAX, you can remove this
def add_membership(request):
    if request.method == "POST":
        try:
            # Get form values
            plan_name = request.POST.get("plan_name")
            duration = request.POST.get("duration")
            price = request.POST.get("price")
            access_level = request.POST.get("access_level") or None
            sessions = request.POST.get("sessions") or None
            status = request.POST.get("status", "inactive")
            description = request.POST.get("description") or None

            # Convert to correct data types
            price = float(price) if price else 0
            sessions = int(sessions) if sessions else None

            # Create Membership
            membership = Membership.objects.create(
                plan_name=plan_name,
                duration=duration,
                price=price,
                access_level=access_level,
                sessions=sessions,
                status=status,
                description=description
            )

            return JsonResponse({
                "success": True,
                "message": "Membership added successfully!",
                "id": membership.id,
                "plan_name": membership.plan_name
            })

        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)}, status=400)

    return JsonResponse({"success": False, "message": "Invalid request"}, status=400)



def edit_membership(request, membership_id):
    if request.method == "POST":
        try:
            membership = get_object_or_404(Membership, id=membership_id)

            plan_name = request.POST.get("plan_name")
            duration = request.POST.get("duration")
            price = request.POST.get("price")
            access_level = request.POST.get("access_level")
            sessions = request.POST.get("sessions")
            status = request.POST.get("status", "inactive")
            description = request.POST.get("description")

            if not all([plan_name, duration, price]):
                return JsonResponse({"status": "error", "message": "Required fields are missing"}, status=400)

            price = float(price) if price else 0
            sessions = int(sessions) if sessions else None

            membership.plan_name = plan_name
            membership.duration = duration
            membership.price = price
            membership.access_level = access_level or None
            membership.sessions = sessions
            membership.status = "active" if status == "active" else "inactive"
            membership.description = description or None
            membership.save()

            return JsonResponse({
                "status": "success",
                "id": membership.id,
                "message": "Membership updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_membership(request, membership_id):
    membership = get_object_or_404(Membership, id=membership_id)
    return JsonResponse({
        "status": "success",
        "membership": {
            "id": membership.id,
            "plan_name": membership.plan_name,
            "duration": membership.duration,
            "price": membership.price,
            "access_level": membership.access_level,
            "sessions": membership.sessions,
            "status": membership.status,
            "description": membership.description,
        }
    })

def delete_membership(request, membership_id):
    membership = get_object_or_404(Membership, id=membership_id)
    membership.delete()
    return redirect('/membership/')  


def add_attendance(request):
    if request.method == "POST":
        client_id = request.POST.get("client_id")
        day = request.POST.get("day")
        date = request.POST.get("date")
        entry_time = request.POST.get("entry_time")
        exit_time = request.POST.get("exit_time")
        status = request.POST.get("status")
        duration = request.POST.get("duration")

        if not (client_id and day and date and entry_time and exit_time and status):
            return JsonResponse({"success": False, "error": "All fields are required."})
        client = get_object_or_404(Client, id=client_id)

        Attendance.objects.create(
            client=client,
            day=day,
            date=parse_date(date),
            entry_time=parse_time(entry_time),
            exit_time=parse_time(exit_time),
            status=status,
            duration=duration
        )

        return JsonResponse({"success": True})

    return JsonResponse({"success": False, "error": "Invalid request method."})

def add_holiday(request):
    if request.method == "POST":
        date = request.POST.get("date")
        remark = request.POST.get("remark")

        try:
            Holiday.objects.create(
                date=date,
                remark=remark
            )
            return JsonResponse({"success": True, "message": "Holiday added successfully!"})
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)})

    return JsonResponse({"success": False, "message": "Invalid request"})

def get_holiday(request, holiday_id):
    holiday = get_object_or_404(Holiday, id=holiday_id)
    return JsonResponse({
        "status": "success",
        "holiday": {
            "id": holiday.id,
            "date": holiday.date.strftime("%Y-%m-%d") if holiday.date else "",
            "remark": holiday.remark,
        }
    })


def edit_holiday(request, holiday_id):
    if request.method == "POST":
        try:
            holiday = get_object_or_404(Holiday, id=holiday_id)

            date = request.POST.get("date")
            remark = request.POST.get("remark")

            if not date or not remark:
                return JsonResponse({"status": "error", "message": "Required fields are missing"}, status=400)

            holiday.date = date
            holiday.remark = remark
            holiday.save()

            return JsonResponse({
                "status": "success",
                "id": holiday.id,
                "message": "Holiday updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

def delete_holiday(request, holiday_id):
    holiday = get_object_or_404(Holiday, id=holiday_id)
    holiday.delete()
    return redirect('/holiday/')


def add_invoice(request):
    if request.method == "POST":
        client_id = request.POST.get("client_id")
        invoice_date = request.POST.get("invoice_date")
        due_date = request.POST.get("due_date")
        payment_method = request.POST.get("payment_method")
        status = request.POST.get("status")

        if not (client_id and invoice_date and due_date and payment_method and status):
            return JsonResponse({"success": False, "error": "All fields are required."})
       
        try:
            client = get_object_or_404(Client, id=client_id)

            if not client.membership_plan:
                return JsonResponse({"success": False, "error": "Client has no membership plan."})

            Invoice.objects.create(
                client=client,
                amount=client.membership_plan.price,   
                invoice_date=parse_date(invoice_date),
                due_date=parse_date(due_date),
                payment_method=payment_method,
                status=status,
            )
            
            return JsonResponse({"success": True})

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "Invalid request method."})

def edit_invoice(request, invoice_id):
    if request.method == "POST":
        try:
            invoice = get_object_or_404(Invoice, id=invoice_id)

            amount = request.POST.get("amount")
            invoice_date = request.POST.get("invoice_date")
            due_date = request.POST.get("due_date")
            payment_method = request.POST.get("payment_method")
            status = request.POST.get("status")

            if not all([amount, invoice_date, due_date, payment_method, status]):
                return JsonResponse({"status": "error", "message": "All fields are required"}, status=400)

            invoice.amount = amount
            invoice.invoice_date = datetime.strptime(invoice_date, "%Y-%m-%d").date()
            invoice.due_date = datetime.strptime(due_date, "%Y-%m-%d").date()
            invoice.payment_method = payment_method
            invoice.status = status
            invoice.save()

            return JsonResponse({"status": "success", "id": invoice.id, "message": "Invoice updated successfully"})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_invoice(request, invoice_id):
    invoice = get_object_or_404(Invoice, id=invoice_id)

    membership = invoice.client.membership_plan  # 👈 get from client

    return JsonResponse({
        "status": "success",
        "invoice": {
            "id": invoice.id,
            "client_id": invoice.client.id,
            "membership_id": membership.id if membership else None,
            "membership_name": f"{membership.plan_name} ({membership.get_duration_display()})" if membership else "No Plan",
            "amount": invoice.amount,
            "invoice_date": invoice.invoice_date.strftime("%Y-%m-%d"),
            "due_date": invoice.due_date.strftime("%Y-%m-%d"),
            "payment_method": invoice.payment_method,
            "status": invoice.status,
        }
    })

def delete_invoice(request, invoice_id):
    invoice = get_object_or_404(Invoice, id=invoice_id)
    client_id = invoice.client.id  
    invoice.delete()
    return redirect('client_detail', client_id=client_id)







def add_designation(request):
    if request.method == "POST":
        name = request.POST.get("name")
        description = request.POST.get("description")
        status = request.POST.get("status")

        # Validation
        if not (name and status):
            return JsonResponse({"success": False, "error": "Name and Status are required."})

        try:
            Designation.objects.create(
                name=name,
                description=description if description else "",
                status=status
            )

            return JsonResponse({"success": True})

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "Invalid request method."})

def edit_designation(request, designation_id):
    if request.method == "POST":
        try:
            designation = get_object_or_404(Designation, id=designation_id)

            name = request.POST.get("name")
            description = request.POST.get("description")
            status = request.POST.get("status")

            if not name:
                return JsonResponse({"status": "error", "message": "Designation name is required"}, status=400)

            designation.name = name
            designation.description = description or ""
            designation.status = "active" if status == "active" else "inactive"
            designation.save()

            return JsonResponse({
                "status": "success",
                "id": designation.id,
                "message": "Designation updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_designation(request, designation_id):
    designation = get_object_or_404(Designation, id=designation_id)
    return JsonResponse({
        "status": "success",
        "designation": {
            "id": designation.id,
            "name": designation.name,
            "description": designation.description,
            "status": designation.status,
        }
    })

def delete_designation(request, designation_id):
    designation = get_object_or_404(Designation, id=designation_id)
    designation.delete()
    return redirect('/designation/')


def add_shift(request):
    if request.method == "POST":
        shift_name = request.POST.get("shift_name")
        shift_type = request.POST.get("shift_type")
        start_time = request.POST.get("start_time")
        end_time = request.POST.get("end_time")
        status = request.POST.get("status", "inactive")


        try:
            Shift.objects.create(
                shift_name=shift_name,
                shift_type=shift_type,
                start_time=start_time,
                end_time=end_time,
                status=status
            )
            return JsonResponse({"success": True, "message": "Shift added successfully!"})
        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)})

    return JsonResponse({"success": False, "message": "Invalid request"})


def get_shift(request, shift_id):
    shift = get_object_or_404(Shift, id=shift_id)
    return JsonResponse({
        "status": "success",
        "shift": {
            "id": shift.id,
            "shift_name": shift.shift_name,
            "shift_type": shift.shift_type,
            "start_time": shift.start_time.strftime("%H:%M") if shift.start_time else "",
            "end_time": shift.end_time.strftime("%H:%M") if shift.end_time else "",
            "status": shift.status,
        }
    })


def edit_shift(request, shift_id):
    if request.method == "POST":
        try:
            shift = get_object_or_404(Shift, id=shift_id)

            shift_name = request.POST.get("shift_name")
            shift_type = request.POST.get("shift_type")
            start_time = request.POST.get("start_time")
            end_time = request.POST.get("end_time")
            status = request.POST.get("status", "inactive")

            if not all([shift_name, shift_type, start_time, end_time]):
                return JsonResponse({"status": "error", "message": "Required fields are missing"}, status=400)

            shift.shift_name = shift_name
            shift.shift_type = shift_type
            shift.start_time = start_time
            shift.end_time = end_time
            shift.status = "active" if status == "active" else "inactive"
            shift.save()

            return JsonResponse({
                "status": "success",
                "id": shift.id,
                "message": "Shift updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

def delete_shift(request, shift_id):
    shift = get_object_or_404(Shift, id=shift_id)
    shift.delete()
    return redirect('/shift/')   


def add_department(request):
    if request.method == "POST":
        name = request.POST.get("department_name")
        status = request.POST.get("status")

        if not name:
            return JsonResponse({"success": False, "message": "Department name is required."})

        if Department.objects.filter(name=name).exists():
            return JsonResponse({"success": False, "message": "Department already exists."})

        dept = Department.objects.create(name=name, status=status)
        return JsonResponse({"success": True, "id": dept.id, "name": dept.name, "status": dept.status})

    return JsonResponse({"success": False, "message": "Invalid request method"})

def get_department(request, pk):
    try:
        department = Department.objects.get(pk=pk)
        return JsonResponse({
            "status": "success",
            "department": {
                "name": department.name,
                "manager": department.manager,
                "status": "active" if department.status else "inactive",
            }
        })
    except Department.DoesNotExist:
        return JsonResponse({"status": "error", "message": "Department not found"})


def edit_department(request, pk):
    if request.method == "POST":
        try:
            department = Department.objects.get(pk=pk)
            department.name = request.POST.get("name")
            department.manager = request.POST.get("manager")
            department.status = True if request.POST.get("status") == "on" else False
            department.save()
            return JsonResponse({"status": "success"})
        except Department.DoesNotExist:
            return JsonResponse({"status": "error", "message": "Department not found"})
    return JsonResponse({"status": "error", "message": "Invalid request"})


def add_trainer(request):
    if request.method == "POST":
        try:
            # Personal Infocustomer-chart
            profile_picture = request.FILES.get("profile_picture")
            yearly_leaves = request.POST.get("yearly_leaves")
            first_name = request.POST.get("first_name")
            last_name = request.POST.get("last_name")
            phone = request.POST.get("phone")
            email = request.POST.get("email")
            gender = request.POST.get("gender")
            date_of_birth_str = request.POST.get("date_of_birth")
            address = request.POST.get("address")

            # Employment Info
            designation_id = request.POST.get("designation")
            department_id = request.POST.get("department")
            shift_id = request.POST.get("shift")
            joining_date_str = request.POST.get("joining_date")
            salary = request.POST.get("salary")
            status = request.POST.get("status", "active")

            # Bank Info
            account_number = request.POST.get("account_number")
            ifsc_code = request.POST.get("ifsc_code")
            bank_name = request.POST.get("bank_name")
            branch_name = request.POST.get("branch_name")

            # ✅ Required field check
            if not all([first_name, phone, email, gender, designation_id, department_id, shift_id, joining_date_str]):
                return JsonResponse({"status": "error", "message": "All required fields must be filled"}, status=400)

            # ✅ Foreign Keys
            designation = get_object_or_404(Designation, id=designation_id)
            department = get_object_or_404(Department, id=department_id)
            shift = get_object_or_404(Shift, id=shift_id)
            
            # ✅ Date conversion
            date_of_birth = datetime.strptime(date_of_birth_str, "%Y-%m-%d").date() if date_of_birth_str else None
            joining_date = datetime.strptime(joining_date_str, "%Y-%m-%d").date()

            # ✅ Create Trainer
            trainer = Trainer.objects.create(
                profile_picture=profile_picture,
                yearly_leaves = yearly_leaves,
                first_name=first_name,
                last_name=last_name,
                phone=phone,
                email=email,
                gender=gender,
                date_of_birth=date_of_birth,
                address=address,
                designation=designation,
                department=department,
                shift=shift,
                joining_date=joining_date,
                salary=salary if salary else None,
                status=status,
                account_number=account_number,
                ifsc_code=ifsc_code,
                bank_name=bank_name,
                branch_name=branch_name,
            )

            return JsonResponse({
                "status": "success",
                "id": trainer.id,
                "message": "Trainer added successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def edit_trainer(request, trainer_id):
    if request.method == "POST":
        try:
            trainer = get_object_or_404(Trainer, id=trainer_id)

            profile_picture = request.FILES.get("profile_picture")
            trainer.yearly_leaves = request.POST.get("yearly_leaves")
            trainer.first_name = request.POST.get("first_name")
            trainer.last_name = request.POST.get("last_name")
            trainer.phone = request.POST.get("phone")
            trainer.email = request.POST.get("email")
            trainer.gender = request.POST.get("gender")
            trainer.date_of_birth = request.POST.get("date_of_birth") or None
            trainer.address = request.POST.get("address")
            trainer.designation_id = request.POST.get("designation")
            trainer.department_id = request.POST.get("department")
            trainer.shift_id = request.POST.get("shift")
            trainer.joining_date = request.POST.get("joining_date")
            trainer.salary = request.POST.get("salary") or None
            trainer.status = request.POST.get("status")
            trainer.account_number = request.POST.get("account_number")
            trainer.ifsc_code = request.POST.get("ifsc_code")
            trainer.bank_name = request.POST.get("bank_name")
            trainer.branch_name = request.POST.get("branch_name")

            if profile_picture:
                trainer.profile_picture = profile_picture

            trainer.save()

            return JsonResponse({"status": "success", "message": "Trainer updated successfully"})

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def get_trainer(request, trainer_id):
    trainer = get_object_or_404(Trainer, id=trainer_id)
    return JsonResponse({
        "status": "success",
        "trainer": {
            "id": trainer.id,
            "first_name": trainer.first_name,
            "yearly_leaves": trainer.yearly_leaves,
            "last_name": trainer.last_name,
            "phone": trainer.phone,
            "email": trainer.email,
            "gender": trainer.gender,
            "date_of_birth": trainer.date_of_birth.strftime("%Y-%m-%d") if trainer.date_of_birth else "",
            "address": trainer.address,
            "designation": trainer.designation.id if trainer.designation else "",
            "department": trainer.department.id if trainer.department else "",
            "shift": trainer.shift.id if trainer.shift else "",
            "joining_date": trainer.joining_date.strftime("%Y-%m-%d") if trainer.joining_date else "",
            "salary": trainer.salary,
            "status": trainer.status,
            "account_number": trainer.account_number,
            "ifsc_code": trainer.ifsc_code,
            "bank_name": trainer.bank_name,
            "branch_name": trainer.branch_name,
        }
    })

def delete_trainer(request, trainer_id):
    trainer = get_object_or_404(Trainer, id=trainer_id)
    trainer.delete()
    return redirect('/trainer/')


def add_staff_attendance(request):
    if request.method == "POST":
        trainer_id = request.POST.get("trainer_id")
        day = request.POST.get("day")
        date = request.POST.get("date")
        entry_time = request.POST.get("entry_time")
        exit_time = request.POST.get("exit_time")
        status = request.POST.get("status")

        if not (trainer_id and day and date and status):
            return JsonResponse({"success": False, "message": "Required fields missing!"})


        trainer = get_object_or_404(Trainer, id=trainer_id)

        if status == "absent":
            entry_time = None
            exit_time = None

        TrainerAttendance.objects.create(
            trainer=trainer,
            day=day,
            date=parse_date(date),
            entry_time=parse_time(entry_time) if entry_time else None,
            exit_time=parse_time(exit_time) if exit_time else None,
            status=status,
        )

        return JsonResponse({"success": True, "message": "Attendance added successfully."})

    return JsonResponse({"success": False, "message": "Invalid request method."})



def get_attendance(request, attendance_id):
    attendance = get_object_or_404(TrainerAttendance, id=attendance_id)
    return JsonResponse({
        "status": "success",
        "attendance": {
            "id": attendance.id,
            "day": attendance.day,
            "date": attendance.date.strftime("%Y-%m-%d") if attendance.date else "",
            "entry_time": attendance.entry_time.strftime("%H:%M") if attendance.entry_time else "",
            "exit_time": attendance.exit_time.strftime("%H:%M") if attendance.exit_time else "",
            "status": attendance.status,
        }
    })


# Edit Attendance
def edit_attendance(request, attendance_id):
    if request.method == "POST":
        try:
            attendance = get_object_or_404(TrainerAttendance, id=attendance_id)

            day = request.POST.get("day")
            date = request.POST.get("date")
            entry_time = request.POST.get("entry_time")
            exit_time = request.POST.get("exit_time")
            status = request.POST.get("status")

            if not (day and date and status):
                return JsonResponse({"status": "error", "message": "Required fields missing"}, status=400)

            # ✅ Handle absent case
            if status == "absent":
                attendance.entry_time = None
                attendance.exit_time = None
            else:
                attendance.entry_time = parse_time(entry_time) if entry_time else None
                attendance.exit_time = parse_time(exit_time) if exit_time else None

            # ✅ Update fields
            attendance.day = day
            attendance.date = parse_date(date)
            attendance.status = status
            attendance.save()

            return JsonResponse({
                "status": "success",
                "id": attendance.id,
                "message": "Attendance updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)


def delete_attendance(request, attendance_id):
    attendance = get_object_or_404(TrainerAttendance, id=attendance_id)
    trainer_id = attendance.trainer_id
    attendance.delete()
    return redirect('trainer_detail', trainer_id=trainer_id)

def generate_invoice_pdf(request, invoice_id):
    invoice = get_object_or_404(Invoice, id=invoice_id)

    # Render template as HTML string
    html_string = render(request, "invoice_template.html", {"invoice": invoice}).content.decode("utf-8")

    # Create PDF
    pdf_file = tempfile.NamedTemporaryFile(delete=True)
    HTML(string=html_string).write_pdf(pdf_file.name)

    # Return as response
    with open(pdf_file.name, "rb") as f:
        pdf = f.read()

    response = HttpResponse(pdf, content_type="application/pdf")
    response["Content-Disposition"] = f'filename="invoice_{invoice.id}.pdf"'
    return response

def add_training(request):
    if request.method == "POST":
        trainer_id = request.POST.get("trainer_id")
        amount = request.POST.get("amount")
        per_session_hours = request.POST.get("per_session_hours")
        training_duration = request.POST.get("training_duration")
        training_sessions = request.POST.get("training_sessions")

        if not (trainer_id and amount and per_session_hours and training_duration and training_sessions):
            return JsonResponse({"success": False, "error": "All fields are required."})

        try:
            trainer = get_object_or_404(Trainer, id=trainer_id)

            training = PersonalTraining.objects.create(
                trainer=trainer,
                amount=amount,
                per_session_hours=per_session_hours,
                training_duration=training_duration,
                training_sessions=training_sessions,
            )

            return JsonResponse({"success": True, "training_id": training.id})

        except Exception as e:
            return JsonResponse({"success": False, "error": str(e)})

    return JsonResponse({"success": False, "error": "Invalid request method."})


def get_training(request, training_id):
    training = get_object_or_404(PersonalTraining, id=training_id)
    return JsonResponse({
        "status": "success",
        "training": {
            "id": training.id,
            "amount": training.amount,
            "per_session_hours": training.per_session_hours,
            "training_duration": training.training_duration,
            "training_sessions": training.training_sessions,
        }
    })


def edit_training(request, training_id):
    if request.method == "POST":
        try:
            training = get_object_or_404(PersonalTraining, id=training_id)

            amount = request.POST.get("amount")
            per_session_hours = request.POST.get("per_session_hours")
            training_duration = request.POST.get("training_duration")
            training_sessions = request.POST.get("training_sessions")

            if not all([amount, per_session_hours, training_duration, training_sessions]):
                return JsonResponse({"status": "error", "message": "All fields are required"}, status=400)

            training.amount = float(amount)
            training.per_session_hours = float(per_session_hours)
            training.training_duration = training_duration
            training.training_sessions = int(training_sessions)
            training.save()

            return JsonResponse({
                "status": "success",
                "id": training.id,
                "message": "Training updated successfully"
            })

        except Exception as e:
            return JsonResponse({"status": "error", "message": str(e)}, status=500)

    return JsonResponse({"status": "error", "message": "Invalid request"}, status=400)

def delete_training(request, training_id):
    training = get_object_or_404(PersonalTraining, id=training_id)
    trainer_id = training.trainer_id
    training.delete()
    return redirect('trainer_detail', trainer_id=trainer_id)

def renew_membership(request):
    if request.method == "POST":
        client_id = request.POST.get("client_id")
        start_date_str = request.POST.get("start_date")
        membership_plan_id = request.POST.get("membership_plan")

        try:
            client = get_object_or_404(Client, id=client_id)
            plan = get_object_or_404(Membership, id=membership_plan_id)

            # ✅ Convert string to date
            start_date = datetime.strptime(start_date_str, "%Y-%m-%d").date()

            # Set new membership details
            client.membership_plan = plan
            client.membership_start = start_date

            duration_map = {
                '1_day': ('days', 1),
                '1_month': ('months', 1),
                '3_months': ('months', 3),
                '6_months': ('months', 6),
                '12_months': ('months', 12),
            }

            duration_type, duration_value = duration_map.get(plan.duration, ('months', 1))

            if duration_type == 'days':
                client.membership_end = start_date + timedelta(days=duration_value)
            else:
                client.membership_end = start_date + relativedelta(months=duration_value)

            client.save()

            return JsonResponse({"success": True, "message": "Membership renewed successfully!"})

        except Exception as e:
            return JsonResponse({"success": False, "message": str(e)})

    return JsonResponse({"success": False, "message": "Invalid request"})

