from django.db import models
from django.utils import timezone
from datetime import timedelta

class Client(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]

    profile_photo = models.ImageField(upload_to='clients/photos/', blank=True, null=True)
    name = models.CharField(max_length=255)
    age = models.PositiveIntegerField()
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, blank=True)

    membership_plan = models.ForeignKey(
        'Membership',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='clients'
    )

    trainer = models.ForeignKey(
        'Trainer',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='clients'
    )

    Personal_training = models.ForeignKey(
        'PersonalTraining',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='clients'
    )

    phone = models.CharField(max_length=20)
    email = models.EmailField(blank=True, null=True)
    join_date = models.DateField()

    # 🆕 Add these two
    membership_start = models.DateField(null=True, blank=True)
    membership_end = models.DateField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if self.membership_plan:
            from dateutil.relativedelta import relativedelta
            from datetime import timedelta

            # Determine duration in months or days
            duration_map = {
                '1_day': ('days', 1),
                '1_month': ('months', 1),
                '3_months': ('months', 3),
                '6_months': ('months', 6),
                '12_months': ('months', 12),
            }

            duration_type, duration_value = duration_map.get(self.membership_plan.duration, ('months', 1))

            # 🧭 Set start date
            if not self.membership_start:
                # New client — start from join date
                self.membership_start = self.join_date
            else:
                # Renewal — start from today or from previous end (whichever is later)
                self.membership_start = max(self.membership_start, timezone.now().date())

            # 📅 Calculate end date
            if duration_type == 'days':
                self.membership_end = self.membership_start + timedelta(days=duration_value)
            else:
                self.membership_end = self.membership_start + relativedelta(months=duration_value)

        super().save(*args, **kwargs)


    # 🧠 Helper methods
    def is_expired(self):
        return self.membership_end and timezone.now().date() > self.membership_end

    def expires_soon(self):
        if not self.membership_end:
            return False
        days_left = (self.membership_end - timezone.now().date()).days
        return 0 <= days_left <= 7




class Membership(models.Model):
    DURATION_CHOICES = [
        ('1_day', 'Trial'),
        ('1_month', '1 Month'),
        ('3_months', '3 Months'),
        ('6_months', '6 Months'),
        ('12_months', '12 Months'),
    ]

    ACCESS_LEVEL_CHOICES = [
        ('basic', 'Basic'),
        ('premium', 'Premium'),
        ('vip', 'VIP'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    plan_name = models.CharField(max_length=100)
    duration = models.CharField(max_length=20, choices=DURATION_CHOICES)
    price = models.DecimalField(max_digits=8, decimal_places=2)  # Example: 99999.99
    access_level = models.CharField(max_length=20, choices=ACCESS_LEVEL_CHOICES, blank=True, null=True)
    sessions = models.PositiveIntegerField(blank=True, null=True)  # Number of trainer sessions
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='active')
    description = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"{self.plan_name} ({self.get_duration_display()})"

class Attendance(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=True, blank=True)
    day = models.CharField(max_length=20)
    date = models.DateField()
    entry_time = models.TimeField()
    exit_time = models.TimeField()
    status = models.CharField(max_length=20)
    duration = models.CharField(max_length=10)

class Invoice(models.Model):
    client = models.ForeignKey("Client", on_delete=models.CASCADE, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)  # e.g., 99999999.99
    invoice_date = models.DateField()
    due_date = models.DateField()
    
    PAYMENT_METHODS = [
        ("cash", "Cash"),
        ("card", "Card"),
        ("upi", "UPI"),
        ("bank_transfer", "Bank Transfer"),
    ]
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    
    STATUS_CHOICES = [
        ("paid", "Paid"),
        ("unpaid", "Unpaid"),
        ("pending", "Pending"),
    ]
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="unpaid")

    created_at = models.DateTimeField(auto_now_add=True)  # track creation
    updated_at = models.DateTimeField(auto_now=True)      # track updates

    def __str__(self):
        return f"Invoice #{self.id} - {self.client} ({self.status})"
 


class Designation(models.Model):
    STATUS_CHOICES = (
        ("active", "Active"),
        ("inactive", "Inactive"),
    )

    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="active")

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Shift(models.Model):
    SHIFT_TYPES = [
        ('morning', 'Morning'),
        ('evening', 'Evening'),
        ('night', 'Night'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]
    shift_name = models.CharField(max_length=100)             # Example: Morning Shift
    shift_type = models.CharField(max_length=20, choices=SHIFT_TYPES)  # Morning/Evening/Night
    start_time = models.TimeField()
    end_time = models.TimeField()
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='active'
    )  # This will store "active" or "inactive"

    def __str__(self):
        return f"{self.shift_name} ({self.shift_type})"


class Department(models.Model):
    STATUS_CHOICES = (
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    )

    name = models.CharField(max_length=100, unique=True)   # Department Name
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='active'
    )
    created_at = models.DateTimeField(auto_now_add=True)   # For record keeping
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class Trainer(models.Model):
    GENDER_CHOICES = [
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ]

    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
    ]

    # Basic info
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100, blank=True, null=True)
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES)
    date_of_birth = models.DateField(blank=True, null=True)
    phone = models.CharField(max_length=15, unique=True)
    email = models.EmailField(unique=True)
    yearly_leaves = models.IntegerField(default=12)  

    # Employment details
    designation = models.ForeignKey("Designation", on_delete=models.SET_NULL, null=True, related_name="trainers")
    department = models.ForeignKey("Department", on_delete=models.SET_NULL, null=True, related_name="trainers")
    shift = models.ForeignKey("Shift", on_delete=models.SET_NULL, null=True, related_name="trainers")

    joining_date = models.DateField()
    salary = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)

    # Extra details
    address = models.TextField(blank=True, null=True)
    profile_picture = models.ImageField(upload_to="trainers/", blank=True, null=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default="active")

    # Bank details
    account_number = models.CharField(max_length=30, blank=True, null=True)
    ifsc_code = models.CharField(max_length=20, blank=True, null=True)
    bank_name = models.CharField(max_length=100, blank=True, null=True)
    branch_name = models.CharField(max_length=100, blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.first_name} {self.last_name or ''}".strip()

class Holiday(models.Model):
    date = models.DateField()
    remark = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.date} - {self.remark}"

class TrainerAttendance(models.Model):
    trainer = models.ForeignKey(Trainer, on_delete=models.CASCADE, null=True, blank=True)
    day = models.CharField(max_length=20)
    date = models.DateField()
    entry_time = models.TimeField(null=True, blank=True)   # ✅ allow NULL
    exit_time = models.TimeField(null=True, blank=True)    # ✅ allow NULL
    status = models.CharField(max_length=20)


    def __str__(self):
        return f"{self.trainer} - {self.date} - {self.status}"

class PersonalTraining(models.Model):
    DURATION_CHOICES = [
        ('1_month', '1 Month'),
        ('3_month', '3 Months'),
        ('6_month', '6 Months'),
        ('12_month', '12 Months'),
    ]

    trainer = models.ForeignKey("Trainer", on_delete=models.CASCADE, related_name="trainings")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    per_session_hours = models.DecimalField(max_digits=5, decimal_places=2)  # e.g., 1.5 hours
    training_duration = models.CharField(max_length=20, choices=DURATION_CHOICES)
    training_sessions = models.IntegerField()

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.trainer} - {self.training_duration} ({self.training_sessions} sessions)"