from django.contrib import admin

# Register your models here.
from .models import Client
admin.site.register(Client)

from .models import Membership
admin.site.register(Membership)

from .models import Attendance
admin.site.register(Attendance)

from .models import Designation
admin.site.register(Designation)

from .models import Shift
admin.site.register(Shift)

from .models import Department
admin.site.register(Department)

from .models import Trainer
admin.site.register(Trainer)

from .models import Invoice
admin.site.register(Invoice)

from .models import Holiday
admin.site.register(Holiday)

from .models import TrainerAttendance
admin.site.register(TrainerAttendance)

from .models import PersonalTraining
admin.site.register(PersonalTraining)   

